class BTNode:
    def __init__ (self,value):
        self.value = value
        self.left = None
        self.right = None

class BST:
    def __init__ (self, root):
        self.root = root

    def add_node(self, value):
        monkey = self.root
        # creating a node that contain value
        new_node = BTNode(value)
        # contructing while loop // stops when I get to a node that points to nothing
        while(monkey):
            # is the new value greater tha or less than current value branch monkey on
            if(value > monkey.value):
                # Is there another branch to climb to grab to?
                if(monkey.right):
                    # if so, climb to that branch
                    monkey = monkey.right
                else:
                    # if not, add new node
                    monkey.right = new_node
                    return self
            else:
                if(monkey.left):
                    monkey = monkey.left
                else:
                    monkey.left = new_node
                    return self
        return self


    def search_for_node(self, value):
        monkey = self.root
        while(monkey):
            if value > monkey.value:
                monkey = monkey.right

            elif value < monkey.value:
                monkey = monkey.left

            else:
                #  value == monkey.value:
                return monkey.value, "I found the node"
        return "NODE NOT FOUND"

    def min(self):
        monkey = self.root
        min = self.root.value
        while(monkey.left):
            if monkey.left.value < min:
                min = monkey.left.value
            else:
                monkey = monkey.left
        return min

    def max(self):
        monkey = self.root
        max = self.root.value
        while(monkey.right):
            if monkey.right.value > max:
                max = monkey.right.value
            else:
                monkey = monkey.right
        return max


# creating search tree
new_bst = BST(BTNode(10))

# print(new_bst, "This is BST object")
# print(new_bst.root, "This is the root of Node object")
# print(new_bst.root.value, "This value my root node contain")

new_bst.add_node(11).add_node(22).add_node(2).add_node(7).add_node(4)
new_bst_nodes = new_bst.add_node(11).add_node(22).add_node(2).add_node(7).add_node(4)

# print(new_bst.root.right.value, "this value just added")
# print(new_bst.root.right.value)

# print(new_bst.search_for_node(22))
# print(new_bst.search_for_node(99))
# print(new_bst_nodes.root.value)

print(new_bst.min())
print(new_bst.max())